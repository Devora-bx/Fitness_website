#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HASH_TABLE_SIZE 29

/* Node structure */
typedef struct node {
    char *filename;    
    int count;         
    struct node *next; 
} node;

/* Linked list structure */
typedef struct {
    node *head; 
} LinkedList;

LinkedList hashTable[HASH_TABLE_SIZE];

char *createStringCopy(char *s);
void initializeHashTable();
void addOrUpdateNode(int number, char *filename);
void processFile(char *filename);
void displayResults();
void freeHashTable();
node *createNode(char *filename);
void freeNodeList(node *head);

int i;

int main(int argc, char *argv[]) {
    /* Check if input files are provided */
    if (argc < 2) {
        fprintf(stderr, "No input files provided\n");
        return EXIT_FAILURE;
    }

    /* Initialize the hash table */
    initializeHashTable();

    /* Process each input file */
    for (i = 1; i < argc; i++) {
        processFile(argv[i]);
    }

    /* Print the results */
    displayResults();

    /* Free the allocated memory */
    freeHashTable();

    return EXIT_SUCCESS;
}

/* Function to create a new copy of a string */
char *createStringCopy(char *s) {
    char *copy = (char *)malloc(strlen(s) + 1);
    if (copy) {
        strcpy(copy, s);
    }
    return copy;
}

/* Function to initialize the hash table */
void initializeHashTable() {
    for (i = 0; i < HASH_TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
    }
}

/* Function to create a new node */
node *createNode(char *filename) {
    node *newNode = (node *)malloc(sizeof(node));
    if (!newNode) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    newNode->filename = createStringCopy(filename);
    if (!newNode->filename) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    newNode->count = 1;
    newNode->next = NULL;
    return newNode;
}

/* Function to add or update a node in the hash table */
void addOrUpdateNode(int number, char *filename) {
    LinkedList *list = &hashTable[number];
    node *current = list->head;
    node *newNode;

    /* Traverse the linked list to find the node with the matching filename */
    while (current != NULL) {
        if (strcmp(current->filename, filename) == 0) {
            current->count++;
            return;
        }
        current = current->next;
    }

    /* Create a new node if filename is not found in the list */
    newNode = createNode(filename);
    newNode->next = list->head;
    list->head = newNode;
}

/* Function to process a file and update the hash table */
void processFile(char *filename) {
    FILE *file;
    int number;

    /* Open the file for reading */
    file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Error opening file: %s\n", filename);
        exit(EXIT_FAILURE);
    }

    /* Read numbers from the file and update the hash table */
    while (fscanf(file, "%d", &number) == 1) {
        addOrUpdateNode(number, filename);
    }

    /* Close the file */
    fclose(file);
}

/* Function to display the results from the hash table */
void displayResults() {
    for (i = 0; i < HASH_TABLE_SIZE; i++) {
        node *current = hashTable[i].head;
        if (current == NULL) 
            continue;

        printf("%d appears", i);
        while (current != NULL) {
            printf(" in file %s - %d time%s", current->filename, current->count, current->count > 1 ? "s" : "");
            current = current->next;
            if (current != NULL) {
                printf(",");
            }
        }
        printf("\n");
    }
}

/* Function to free the memory allocated for a linked list */
void freeNodeList(node *head) {
    node *current = head;
    while (current != NULL) {
        node *temp = current;
        current = current->next;
        free(temp->filename);
        free(temp);
    }
}

/* Function to free the memory allocated for the hash table */
void freeHashTable() {
    for (i = 0; i < 29; i++) {
        freeNodeList(hashTable[i].head);
    }
}

